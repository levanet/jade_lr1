import jade.core.Runtime;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.StaleProxyException;

public class Main {

    public static void main(String[] args) {
        try {
            // Getting an instance of Runtime for JADE
            Runtime runtime = Runtime.instance();

            // Setting up a profile for creating the main container
            Profile profile = new ProfileImpl();
            profile.setParameter(Profile.MAIN_HOST, "localhost");
            profile.setParameter(Profile.GUI, "true");

            // Creating the main container
            AgentContainer mainContainer = runtime.createMainContainer(profile);

            // Setting up a profile for creating an additional container for sellers
            Profile sellerProfile = new ProfileImpl();
            sellerProfile.setParameter(Profile.MAIN_HOST, "localhost");
            sellerProfile.setParameter(Profile.CONTAINER_NAME, "Sellers-Container");
            mainContainer = runtime.createAgentContainer(sellerProfile);

            // Creating seller agents
            for (int i = 1; i <= 2; i++) {
                String agentName = "Book_Seller" + i;
                AgentController seller = mainContainer.createNewAgent(agentName, "com.books.BookSellerAgent", null);
                seller.start();
            }

            // Setting up a profile for creating an additional container for buyers
            Profile buyerProfile = new ProfileImpl();
            buyerProfile.setParameter(Profile.MAIN_HOST, "localhost");
            buyerProfile.setParameter(Profile.CONTAINER_NAME, "Buyers-Container");
            mainContainer = runtime.createAgentContainer(buyerProfile);

            // Creating a buyer agent
            String buyerName = "Buyer_1";
            AgentController buyer = mainContainer.createNewAgent(buyerName, "com.books.BookBuyerAgent", new Object[]{"The Witcher"});
            buyer.start();
        } catch (StaleProxyException e) {
            e.printStackTrace();
        }
    }
}
